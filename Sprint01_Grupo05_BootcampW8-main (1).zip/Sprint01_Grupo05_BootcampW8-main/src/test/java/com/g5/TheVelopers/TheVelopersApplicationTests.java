package com.g5.TheVelopers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheVelopersApplicationTests {

	@Test
	void contextLoads() {
	}

}
