# SocialMeli - Projeto (Sprint I)

### Integrantes
- Daniele Souza Goncalves
- Guilherme Bensi
- Igor Oliveira Rodrigues
-  Laise Farias France
-  Mariana Souza do Carmo


#### Link Collection Postman: 
https://socialmelithevelopers.postman.co/workspace/SocialMeli_TheVelopers-Workspac~a0d24fde-0059-4293-83fa-5f953ab1e5ff/collection/37089408-8bd81643-231f-40cf-994f-f19791aa5a37?action=share&creator=37089408
