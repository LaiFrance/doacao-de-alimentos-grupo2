package com.g5.TheVelopers.services;

import com.g5.TheVelopers.dtos.ProductDto;
import com.g5.TheVelopers.entities.Product;
import com.g5.TheVelopers.repositories.interfaces.IProductRepository;
import com.g5.TheVelopers.services.interfaces.IProductService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {
    IProductRepository productRepository;
    public ProductServiceImpl(IProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public List<ProductDto> findAll() {
        List<Product> products = productRepository.findAll();
        return products.stream().map(this::productToDto).toList();
    }

    private ProductDto productToDto(Product p){
        return new ProductDto(p);
    }
}
