package com.g5.TheVelopers.repositories.interfaces;

import java.util.List;

import com.g5.TheVelopers.entities.User;

public interface IUserRepository {
    User getById(Integer id);
    List<User> getByIds(List<Integer> ids);
    List<User> findAll();
    void followSeller(Integer userId, Integer userIdToFollow);
    List<Integer> followedList(Integer userId);
    void unfollowSeller(Integer userId, Integer userIdToUnfollow);
}
