package com.g5.TheVelopers.entities;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromoPost extends Post {
    private Boolean hasPromo;
    private Double discount;
    
    public PromoPost(Integer id, Integer userId, Integer productId, LocalDate date, Boolean hasPromo, Double discount) {
        super(id, userId, productId, date);
        this.hasPromo = hasPromo;
        this.discount = discount;
    }
}
