package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Seller;

import lombok.Getter;

@Getter
public class PromoPostCountDto {
    private Integer userId;
    private String userName;
    private Integer promoProductsCount;

    public PromoPostCountDto(Seller seller) {
        this.userId = seller.getId();
        this.userName = seller.getName();
        this.promoProductsCount = seller.getPromoPostIds().size();
    }
}
