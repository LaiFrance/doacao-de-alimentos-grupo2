package com.g5.TheVelopers.services;

import com.g5.TheVelopers.dtos.FollowingListDto;
import com.g5.TheVelopers.dtos.UserDto;
import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.entities.User;
import com.g5.TheVelopers.exceptions.NotFoundException;
import com.g5.TheVelopers.repositories.interfaces.ISellerRepository;
import com.g5.TheVelopers.repositories.interfaces.IUserRepository;
import com.g5.TheVelopers.services.interfaces.IUserService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserServiceImpl implements IUserService {

    IUserRepository userRepository;
    ISellerRepository sellerRepository;

    public UserServiceImpl(IUserRepository userRepository, ISellerRepository sellerRepository) {
        this.userRepository = userRepository;
        this.sellerRepository = sellerRepository;
    }

    @Override
    public List<UserDto> findAll(){
        List<User> users = userRepository.findAll();
        return users.stream().map(this::userToDto).toList();
    }
    
    @Override
    public FollowingListDto getFollowersSortedByName(Integer userId, String order) {
        
        // buscando usuario pelo id
        User user = userRepository.getById(userId);
        
        // validando existencia do usuario
        if(user == null) {
            throw new NotFoundException("Não foi encontrado nenhum vendedor.");
        }

        // buscando lista de vendedores que o usuário segue
        List<Seller> sellers = sellerRepository.getByIds(user.getFollowingIds());

        if(order.equalsIgnoreCase("name_asc")) {
            sellers = sellers.stream().sorted((object1, object2) -> object1.getName().compareTo(object2.getName())).toList();
        }

        if(order.equalsIgnoreCase("name_desc")) {
            sellers = sellers.stream().sorted((object1, object2) -> object2.getName().compareTo(object1.getName())).toList();
        }

        return new FollowingListDto(user, sellers);
    }

    @Override
    public void followSeller(Integer userId, Integer userIdToFollow){

        if (sellerRepository.getById(userIdToFollow) == null){
            throw new NotFoundException("Seller not found");
        }
        userRepository.followSeller(userId, userIdToFollow);
        sellerRepository.addFollower(userId, userIdToFollow);
        
    }
    @Override
    public FollowingListDto followedList(Integer userId) {
        List<Integer> followedIds = userRepository.followedList(userId);
        List<Seller> followedSellers = sellerRepository.getByIds(followedIds);
        User user = userRepository.getById(userId);
        
        if(followedIds.isEmpty() || followedSellers.isEmpty()){
            throw new NotFoundException("Not found followed ids");
        }

        if(user == null){
            throw new NotFoundException("User not found");
        }
        return new FollowingListDto(user, followedSellers);
    }
    

    @Override
    public void unfollowSeller(Integer userId, Integer userIdToUnfollow){

        if (sellerRepository.getById(userIdToUnfollow) == null){
            throw new NotFoundException("Seller not found");
        }
        userRepository.unfollowSeller(userId, userIdToUnfollow);
        sellerRepository.removeFollower(userId, userIdToUnfollow);
        
    }

    private UserDto userToDto(User user) {
        return new UserDto(user);
    }

}
