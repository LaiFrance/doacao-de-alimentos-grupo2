package com.g5.TheVelopers.dtos;

import java.time.LocalDate;

import com.g5.TheVelopers.entities.Post;
import com.g5.TheVelopers.entities.Product;

import lombok.Getter;

@Getter
public class PostDto {
    private Integer userId;
    private LocalDate date;
    private ProductDto product;
    private Integer category;
    private Double price;

    public PostDto(Post post, Product product) {
        this.userId = post.getUserId();
        this.date = post.getDate();
        this.product = new ProductDto(product);
        this.category = product.getCategory();
        this.price = product.getPrice();
    }
}
