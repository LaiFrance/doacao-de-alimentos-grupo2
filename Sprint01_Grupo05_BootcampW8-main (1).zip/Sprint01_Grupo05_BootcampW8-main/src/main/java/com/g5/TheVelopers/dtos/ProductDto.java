package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Product;

import lombok.Getter;

@Getter
public class ProductDto {
    private Integer productId;
    private String productName;
    private String type;
    private String brand;
    private String color;
    private String notes;
    private Integer category;
    private Double price;

    public ProductDto(Product product) {
        this.productId = product.getId();
        this.productName = product.getName();
        this.type = product.getType();
        this.brand = product.getBrand();
        this.color = product.getColor();
        this.notes = product.getNotes();
        this.category = product.getCategory();
        this.price = product.getPrice();
    }
}
