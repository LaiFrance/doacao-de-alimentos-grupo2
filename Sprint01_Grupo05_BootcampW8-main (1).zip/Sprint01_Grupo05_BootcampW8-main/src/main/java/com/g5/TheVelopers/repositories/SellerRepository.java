package com.g5.TheVelopers.repositories;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.exceptions.NotFoundException;
import com.g5.TheVelopers.repositories.interfaces.ISellerRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.ResourceUtils;

@Repository
public class SellerRepository implements ISellerRepository {
    private List<Seller> sellers = new ArrayList<>();

    public SellerRepository() throws IOException {
        loadDataBase();
    }

    @Override
    public Seller getById(Integer id) {
        return this.sellers.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Seller> getByIds(List<Integer> ids) {
        return this.sellers.stream().filter(s -> ids.contains(s.getId())).toList();
    }

    @Override
    public List<Seller> findAll() {
        return new ArrayList<>(this.sellers);
    }

    @Override
    public void addFollower(Integer userId, Integer userIdToFollow) {
        Seller seller = getById(userIdToFollow);

        if (seller == null) {
            throw new NotFoundException("User not found");
        }

        seller.getFollowerIds().add(userId);
    }

    @Override
    public void removeFollower(Integer userId, Integer userIdToUnfollow) {
        Seller seller = getById(userIdToUnfollow);

        if (seller == null) {
            throw new NotFoundException("User not found");
        }
        List<Integer> followersIds = seller.getFollowerIds();
        followersIds.remove(Integer.valueOf(userIdToUnfollow));
    }

    @Override
    public Integer getFollowersCount(Integer sellerId) {
        Seller seller = getById(sellerId);
        if (seller != null) {
            List<Integer> followerIds = seller.getFollowerIds();
            if (followerIds.isEmpty()) {
                return 0;
            } else {
                return followerIds.size();
            }
        }
        return 0;
    }

    @Override
    public List<Integer> getFollowers(Integer sellerId) {
        Seller seller = getById(sellerId);
        if (seller != null) {
            return seller.getFollowerIds();
        }
        return new ArrayList<>();
    }

    private void loadDataBase() throws IOException {
        File file;
        ObjectMapper objectMapper = new ObjectMapper();
        List<Seller> sellerslist;

        file = ResourceUtils.getFile("classpath:sellers.json");
        sellerslist = objectMapper.readValue(file, new TypeReference<List<Seller>>() {
        });
        sellers = sellerslist;
    }
}



