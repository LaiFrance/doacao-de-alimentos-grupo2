package com.g5.TheVelopers.exceptions;

public class UserNotFoundException extends NotFoundException {
    public UserNotFoundException(Integer id) {
        super("User with id " + id + " not found");
    }
}
