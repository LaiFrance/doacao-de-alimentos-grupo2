package com.g5.TheVelopers.services.interfaces;

import com.g5.TheVelopers.dtos.PostDto;
import com.g5.TheVelopers.entities.Post;

import java.util.List;

public interface IPostService {
    List<PostDto> findAll();
    List<PostDto> getLastPostsForUser(Integer userId);
    void create(Post post);
    List<PostDto> getUserPostsOrdered(Integer userId, String order);
}
