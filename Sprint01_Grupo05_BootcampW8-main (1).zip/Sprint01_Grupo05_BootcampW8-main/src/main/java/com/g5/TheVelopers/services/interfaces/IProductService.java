package com.g5.TheVelopers.services.interfaces;

import com.g5.TheVelopers.dtos.ProductDto;

import java.util.List;

public interface IProductService {
    List<ProductDto> findAll();
}
