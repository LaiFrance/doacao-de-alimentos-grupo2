package com.g5.TheVelopers.controllers;
import com.g5.TheVelopers.dtos.FollowersCountDto;
import com.g5.TheVelopers.services.interfaces.ISellerService;
import com.g5.TheVelopers.services.interfaces.IUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("users")
public class UserController {

    IUserService userService;
    ISellerService sellerService;
    
    public UserController(IUserService userService, ISellerService sellerService) {
        this.userService = userService;
        this.sellerService = sellerService;
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllUsers(){
        return new ResponseEntity<>(userService.findAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/{userId}/followers/list", params = {"order"})
    public ResponseEntity<?> getFollowersSortedByName (@PathVariable Integer userId, @RequestParam String order) {
        return new ResponseEntity<>(sellerService.getFollowersSortedByName(userId, order),HttpStatus.OK);
    }

    @GetMapping(value = "/{userId}/followed/list", params = {"order"})
    public ResponseEntity<?> getFollowedSortedByName (@PathVariable Integer userId, @RequestParam String order) {
        return new ResponseEntity<>(userService.getFollowersSortedByName(userId, order),HttpStatus.OK);
    }
    
    @PostMapping("/{userId}/follow/{userIdToFollow}")
    public ResponseEntity<?> followSeller(@PathVariable Integer userId,
      @PathVariable Integer userIdToFollow){
        userService.followSeller(userId, userIdToFollow);
        return new ResponseEntity<>( HttpStatus.OK);
    }
    
    @GetMapping("/{userId}/followed/list")
    public ResponseEntity<?> followedList(@PathVariable Integer userId) {
        return new ResponseEntity<>(userService.followedList(userId), HttpStatus.OK);
    }

    @PostMapping("/{userId}/unfollow/{userIdToUnfollow}")
    public ResponseEntity<?> unfollowSeller(@PathVariable Integer userId,
      @PathVariable Integer userIdToUnfollow){
        userService.unfollowSeller(userId, userIdToUnfollow);
        return new ResponseEntity<>( HttpStatus.OK);
    }

    @GetMapping("/{userId}/followers/count")
    public ResponseEntity<?> getFollowersCount(@PathVariable Integer userId) {
        FollowersCountDto followersCountDto = sellerService.getSellerFollowersCount(userId);
        if (followersCountDto != null) {
            return ResponseEntity.ok(followersCountDto);
        }

        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{userId}/followers/list")
    public ResponseEntity<?> getFollowersList(@PathVariable Integer userId) {
        var followers = sellerService.getSellerFollowers(userId);
        if (followers != null) {
            return ResponseEntity.ok(followers);
        }

        return ResponseEntity.notFound().build();
    }
}
