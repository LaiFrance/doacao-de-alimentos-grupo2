package com.g5.TheVelopers.repositories;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.g5.TheVelopers.entities.Product;
import com.g5.TheVelopers.repositories.interfaces.IProductRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.ResourceUtils;

@Repository
public class ProductRepository implements IProductRepository {
    private List<Product> products = new ArrayList<>();

    public ProductRepository() throws IOException {
        loadDataBase();
    }

    @Override
    public Product getById(Integer id) {
        return this.products.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Product> getByIds(List<Integer> ids) {
        return this.products.stream().filter(p -> ids.contains(p.getId())).toList();
    }

    @Override
    public List<Product> findAll() {
        return new ArrayList<>(this.products);
    }

    private void loadDataBase() throws IOException {
        File file;
        ObjectMapper objectMapper = new ObjectMapper();
        List<Product> productsList;

        file = ResourceUtils.getFile("classpath:products.json");
        productsList = objectMapper.readValue(file, new TypeReference<List<Product>>(){});
        products = productsList;
    }
}
