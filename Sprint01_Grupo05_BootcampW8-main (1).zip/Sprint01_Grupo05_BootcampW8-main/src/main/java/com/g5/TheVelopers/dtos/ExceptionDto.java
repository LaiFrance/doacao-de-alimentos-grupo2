package com.g5.TheVelopers.dtos;

public record ExceptionDto(String msg) {
}
