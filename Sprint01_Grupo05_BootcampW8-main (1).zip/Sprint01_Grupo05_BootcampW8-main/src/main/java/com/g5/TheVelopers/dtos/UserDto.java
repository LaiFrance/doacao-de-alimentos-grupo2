package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.User;
import lombok.Getter;

import java.util.List;

@Getter
public class UserDto{
    private Integer userId;
    private String username;
    private List<Integer> followingIds;

    public UserDto(User user) {
        this.userId = user.getId();
        this.username = user.getName();
        this.followingIds = user.getFollowingIds();
    }
}
