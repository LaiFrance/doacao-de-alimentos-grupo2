package com.g5.TheVelopers.services.interfaces;

import com.g5.TheVelopers.dtos.FollowersCountDto;
import com.g5.TheVelopers.dtos.FollowedListDto;
import com.g5.TheVelopers.dtos.SellerDto;

import java.util.List;

public interface ISellerService {
    List<SellerDto> findAll();
    FollowedListDto getSellerFollowers(Integer userId);
    FollowersCountDto getSellerFollowersCount(Integer userId);
    FollowedListDto getFollowersSortedByName (Integer userId,String order);
}
