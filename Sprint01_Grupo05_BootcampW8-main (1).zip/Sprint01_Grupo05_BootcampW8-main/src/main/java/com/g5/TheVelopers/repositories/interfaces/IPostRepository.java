package com.g5.TheVelopers.repositories.interfaces;

import com.g5.TheVelopers.entities.Post;

import java.time.LocalDate;
import java.util.List;


public interface IPostRepository {
    Post getById(Integer id);
    List<Post> getByIds(List<Integer> ids);
    List<Post> findAll();
    List<Post> findOfSellerFromDateUntilNow(Integer sellerId, LocalDate start);
    void save(Post post);
}
