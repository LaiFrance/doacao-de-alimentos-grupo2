package com.g5.TheVelopers.services;
import com.g5.TheVelopers.dtos.FollowersCountDto;
import com.g5.TheVelopers.dtos.FollowedListDto;
import com.g5.TheVelopers.dtos.SellerDto;
import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.entities.User;
import com.g5.TheVelopers.exceptions.NotFoundException;
import com.g5.TheVelopers.exceptions.SellerNotFoundException;
import com.g5.TheVelopers.repositories.interfaces.ISellerRepository;
import com.g5.TheVelopers.repositories.interfaces.IUserRepository;
import com.g5.TheVelopers.services.interfaces.ISellerService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SellerServiceImpl implements ISellerService {

    ISellerRepository sellerRepository;
    IUserRepository userRepository;

    public SellerServiceImpl(ISellerRepository sellerRepository, IUserRepository userRepository) {
        this.sellerRepository = sellerRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<SellerDto> findAll(){
        List<Seller> users = sellerRepository.findAll();
        return users.stream().map(this::sellerToDto).toList();
    }
  
    @Override
    public FollowedListDto getSellerFollowers(Integer userId) {
        var seller = this.sellerRepository.getById(userId);

        if (seller == null) {
            throw new SellerNotFoundException();
        }

        return new FollowedListDto(seller, this.userRepository.getByIds(seller.getFollowerIds()));
    }

    @Override
    public FollowersCountDto getSellerFollowersCount(Integer userId) {
        return new FollowersCountDto(this.sellerRepository.getById(userId));
    }
      
    @Override
    public FollowedListDto getFollowersSortedByName (Integer userId, String order) {

        // buscando vendedor pelo id
        Seller seller = sellerRepository.getById(userId);

        // validando existencia do vendedor
        if(seller == null) {
            throw new NotFoundException("Não foi encontrado nenhum vendedor.");
        }

        // buscando lista de usuarios que seguem o vendedor
        List<User> users = userRepository.getByIds(seller.getFollowerIds());

        if(order.equalsIgnoreCase("name_asc")) {
            users = users.stream().sorted((object1, object2) -> object1.getName().compareTo(object2.getName())).toList();
        }

        if(order.equalsIgnoreCase("name_desc")) {
            users = users.stream().sorted((object1, object2) -> object2.getName().compareTo(object1.getName())).toList();
        }

        return new FollowedListDto(seller, users);
    }

    private SellerDto sellerToDto(Seller seller) {
        return new SellerDto(seller);
    }
}
