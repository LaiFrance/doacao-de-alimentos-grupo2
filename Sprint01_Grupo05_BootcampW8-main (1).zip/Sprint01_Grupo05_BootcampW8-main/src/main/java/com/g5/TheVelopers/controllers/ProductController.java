package com.g5.TheVelopers.controllers;

import com.g5.TheVelopers.entities.Post;
import com.g5.TheVelopers.services.interfaces.IPostService;
import com.g5.TheVelopers.services.interfaces.IProductService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("products")
public class ProductController {
    private IProductService productService;
    private IPostService postService;

    public ProductController(IProductService productService, IPostService postService) {
        this.productService = productService;
        this.postService = postService;
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllProducts(){
        return new ResponseEntity<>(productService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/followed/{userId}/list")
    public ResponseEntity<?> getLastPostsForUser(@PathVariable Integer userId) {
        return new ResponseEntity<>(this.postService.getLastPostsForUser(userId), HttpStatus.OK);
    }

    @PostMapping("/post")
    public ResponseEntity<?> addPost(@RequestBody Post post) {
        this.postService.create(post);
        return new ResponseEntity<>(this.postService.findAll(),HttpStatus.OK);
    }

    @GetMapping(value = "/followed/{userId}/list", params = {"order"})
    public ResponseEntity<?> getFollowersSortedByName (@PathVariable Integer userId, @RequestParam String order) {
        return new ResponseEntity<>(this.postService.getUserPostsOrdered(userId, order),HttpStatus.OK);
    }
}
