package com.g5.TheVelopers.repositories.interfaces;

import java.util.List;

import com.g5.TheVelopers.entities.Product;

public interface IProductRepository {
    Product getById(Integer id);
    List<Product> getByIds(List<Integer> ids);
    List<Product> findAll();
}
