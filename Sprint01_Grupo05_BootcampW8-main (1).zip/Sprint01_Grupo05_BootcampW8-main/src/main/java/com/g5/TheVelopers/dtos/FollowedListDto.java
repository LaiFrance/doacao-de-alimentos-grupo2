package com.g5.TheVelopers.dtos;

import java.util.List;

import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.entities.User;

import lombok.Getter;

@Getter
public class FollowedListDto {
    private Integer userId;
    private String userName;
    private List<FollowDto> followed;

    public FollowedListDto(Seller seller, List<User> followed) {
        this.userId = seller.getId();
        this.userName = seller.getName();
        this.followed = followed.stream().map(u -> new FollowDto(u)).toList();
    }
}
