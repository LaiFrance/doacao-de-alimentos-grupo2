package com.g5.TheVelopers.exceptions;

public class SellerNotFoundException extends NotFoundException {
    public SellerNotFoundException() {
        super("Seller not found");
    }
}
