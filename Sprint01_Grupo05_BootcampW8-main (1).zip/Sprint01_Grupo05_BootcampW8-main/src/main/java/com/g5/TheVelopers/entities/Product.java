package com.g5.TheVelopers.entities;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Product {
    private Integer id;
    private String name;
    private String type;
    private String brand;
    private String color;
    private String notes;
    private Integer category;
    private Double price;
}
