package com.g5.TheVelopers.dtos;

import java.util.List;

import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.entities.User;

import lombok.Getter;

@Getter
public class FollowingListDto {
    private Integer userId;
    private String userName;
    private List<FollowDto> followers;

    public FollowingListDto(User user, List<Seller> followers) {
        this.userId = user.getId();
        this.userName = user.getName();
        this.followers = followers.stream().map((f) -> new FollowDto(f)).toList();
    }
}
