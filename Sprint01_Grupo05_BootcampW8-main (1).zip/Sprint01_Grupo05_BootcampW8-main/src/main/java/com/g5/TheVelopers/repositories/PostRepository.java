package com.g5.TheVelopers.repositories;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.g5.TheVelopers.dtos.PostRawDto;
import com.g5.TheVelopers.entities.Post;
import com.g5.TheVelopers.repositories.interfaces.IPostRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.ResourceUtils;

@Repository
public class PostRepository implements IPostRepository {
    private List<Post> posts = new ArrayList<>();

    public PostRepository() throws IOException {
        loadDataBase();
    }

    @Override
    public Post getById(Integer id) {
        return this.posts.stream().filter(p -> p.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Post> getByIds(List<Integer> ids) {
        return this.posts.stream().filter(p -> ids.contains(p.getId())).toList();
    }

    @Override
    public List<Post> findAll() {
        return new ArrayList<>(this.posts);
    }

    @Override
    public void save(Post post){
        this.posts.add(post);
    }

    @Override
    public List<Post> findOfSellerFromDateUntilNow(Integer sellerId, LocalDate start) {
        return this.posts.stream().filter(p -> p.getUserId().equals(sellerId) && p.getDate().isAfter(start)).toList();
    }

    private void loadDataBase() throws IOException {
        File file;
        ObjectMapper objectMapper = new ObjectMapper();
        List<PostRawDto> postsList;

        file = ResourceUtils.getFile("classpath:posts.json");
        postsList = objectMapper.readValue(file, new TypeReference<List<PostRawDto>>(){});
        posts = new ArrayList<>(postsList.stream().map(PostRawDto::toPost).toList());
    }
}
