package com.g5.TheVelopers.services.interfaces;
import com.g5.TheVelopers.dtos.FollowingListDto;
import com.g5.TheVelopers.dtos.UserDto;
import java.util.List;

public interface IUserService {
    List<UserDto> findAll();
    FollowingListDto getFollowersSortedByName (Integer userId, String order);
    void followSeller(Integer userId, Integer userIdToFollow);
    FollowingListDto followedList(Integer userId);
    void unfollowSeller(Integer userId, Integer userIdToUnfollow);
}
