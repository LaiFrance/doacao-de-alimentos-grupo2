package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Seller;
import lombok.Getter;

import java.util.List;

@Getter
public class SellerDto{
    private Integer sellerId;
    private String sellerName;
    private List<Integer> followerIds;
    private List<Integer> postIds;
    private List<Integer> promoPostIds;

    public SellerDto(Seller seller) {
        this.sellerId = seller.getId();
        this.sellerName = seller.getName();
        this.followerIds = seller.getFollowerIds();
        this.postIds = seller.getPostIds();
        this.promoPostIds = seller.getPromoPostIds();
    }
}
