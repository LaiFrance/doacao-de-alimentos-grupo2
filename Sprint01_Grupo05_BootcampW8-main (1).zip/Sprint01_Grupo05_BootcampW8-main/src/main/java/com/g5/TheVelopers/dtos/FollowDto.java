package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Seller;
import com.g5.TheVelopers.entities.User;

import lombok.Getter;

@Getter
public class FollowDto {
    private Integer id;
    private String name;

    public FollowDto(User user) {
        this.id = user.getId();
        this.name = user.getName();
    }

    public FollowDto(Seller seller) {
        this.id = seller.getId();
        this.name = seller.getName();
    }
}
