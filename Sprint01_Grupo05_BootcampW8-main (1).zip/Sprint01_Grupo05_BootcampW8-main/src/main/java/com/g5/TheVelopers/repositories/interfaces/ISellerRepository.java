package com.g5.TheVelopers.repositories.interfaces;

import java.util.List;

import com.g5.TheVelopers.entities.Seller;

public interface ISellerRepository {
    Seller getById(Integer id);
    List<Seller> getByIds(List<Integer> ids);
    List<Seller> findAll();
    public void addFollower(Integer userId, Integer userIdToFollow);
    public void removeFollower(Integer userId, Integer userIdToUnfollow);

    Integer getFollowersCount(Integer sellerId);

    List<Integer> getFollowers(Integer sellerId);
}
