package com.g5.TheVelopers.dtos;

import java.util.List;

import com.g5.TheVelopers.entities.Seller;

import lombok.Getter;

@Getter
public class PromoPostListDto {
    private Integer userId;
    private String userName;
    private List<PromoPostDto> posts;

    public PromoPostListDto(Seller seller, List<PromoPostDto> posts) {
        this.userId = seller.getId();
        this.userName = seller.getName();
        this.posts = posts;
    }
}
