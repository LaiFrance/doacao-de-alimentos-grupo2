package com.g5.TheVelopers.entities;

import lombok.*;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
public class Post {
    private Integer id;
    private Integer userId;
    private Integer productId;
    private LocalDate date;
}
