package com.g5.TheVelopers.entities;

import java.util.List;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Seller {
    private Integer id;
    private String name;
    private List<Integer> followerIds;
    private List<Integer> postIds;
    private List<Integer> promoPostIds;
}
