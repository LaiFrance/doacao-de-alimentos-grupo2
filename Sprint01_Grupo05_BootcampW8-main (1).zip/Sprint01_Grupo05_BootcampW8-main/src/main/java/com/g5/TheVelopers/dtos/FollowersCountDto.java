package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Seller;

import lombok.Getter;

@Getter
public class FollowersCountDto {
    private Integer userId;
    private String userName;
    private Integer followersCount;

    public FollowersCountDto(Seller seller) {
        this.userId = seller.getId();
        this.userName = seller.getName();
        this.followersCount = seller.getFollowerIds().size();
    }
}
