package com.g5.TheVelopers.entities;

import java.util.List;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class User {
    Integer id;
    String name;
    List<Integer> followingIds;
}
