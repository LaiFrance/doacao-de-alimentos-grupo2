package com.g5.TheVelopers.services;

import com.g5.TheVelopers.dtos.PostDto;
import com.g5.TheVelopers.entities.Post;
import com.g5.TheVelopers.entities.Product;
import com.g5.TheVelopers.exceptions.NotFoundException;
import com.g5.TheVelopers.exceptions.UserNotFoundException;
import com.g5.TheVelopers.repositories.interfaces.IPostRepository;
import com.g5.TheVelopers.repositories.interfaces.IProductRepository;
import com.g5.TheVelopers.repositories.interfaces.IUserRepository;
import com.g5.TheVelopers.services.interfaces.IPostService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Service
public class PostServiceImpl implements IPostService {
    private IProductRepository productRepository;
    private IPostRepository postRepository;
    private IUserRepository userRepository;

    public PostServiceImpl(IPostRepository postRepository, IProductRepository productRepository, IUserRepository userRepository) {
        this.postRepository = postRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<PostDto> findAll(){
        List<Post> posts = postRepository.findAll();
        return posts.stream().map(this::postToDto).toList();
    }

    @Override
    public List<PostDto> getLastPostsForUser(Integer userId) {
        var user = this.userRepository.getById(userId);

        if (user == null) {
            throw new UserNotFoundException(userId);
        }

        LocalDate start = LocalDate.now().minusWeeks(2L);

        return user.getFollowingIds().stream().flatMap((Integer id) ->
            this.postRepository.findOfSellerFromDateUntilNow(id, start)
                .stream().map(this::postToDto)
        ).toList();
    }

    @Override
    public void create(Post post) {
        this.postRepository.save(post);
    }

    @Override
    public List<PostDto> getUserPostsOrdered(Integer userId, String order){
        if(order.equalsIgnoreCase("date_asc")){ return this.postRepository.findAll().stream().filter(i -> i.getUserId().equals(userId))
                .sorted(Comparator.comparing(Post::getDate)).map(this::postToDto).toList(); }
        else if(order.equalsIgnoreCase("date_desc")){ return this.postRepository.findAll().stream().filter(i -> i.getUserId().equals(userId))
                .sorted((object1, object2) -> object2.getDate().compareTo(object1.getDate())).map(this::postToDto).toList(); }
        else{ throw new NotFoundException("ORDER DOESNT EXIST");
        }
    }

    private PostDto postToDto(Post post) {
        Product postProducts = productRepository.getById(post.getProductId());
        return new PostDto(post, postProducts);
    }
}
