package com.g5.TheVelopers.repositories;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.g5.TheVelopers.entities.User;
import com.g5.TheVelopers.exceptions.NotFoundException;
import com.g5.TheVelopers.repositories.interfaces.IUserRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.ResourceUtils;

@Repository
public class UserRepository implements IUserRepository {
    private List<User> users = new ArrayList<>();

    public UserRepository() throws IOException {
        loadDataBase();
    }

    @Override
    public User getById(Integer id) {
        return this.users.stream().filter(u -> u.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<User> getByIds(List<Integer> ids) {
        return this.users.stream().filter(u -> ids.contains(u.getId())).toList();
    }

    @Override
    public List<User> findAll() {
        return new ArrayList<>(this.users);
    }

    @Override
    public void followSeller(Integer userId, Integer userIdToFollow){
        User user = getById(userId);

        if (user == null){
            throw new NotFoundException("User not found");
        }

        user.getFollowingIds().add(userIdToFollow);
    }

    @Override
    public  List <Integer> followedList(Integer userId){
        List<Integer> followedIds = getById(userId).getFollowingIds();

        return followedIds;
     }

     @Override
     public void unfollowSeller(Integer userId, Integer userIdToUnfollow){
        User user = getById(userId);

        if (user == null){
            throw new NotFoundException("User not found");
        }

        List <Integer> followingids = user.getFollowingIds();

        boolean result = followingids.remove(Integer.valueOf(userIdToUnfollow));

        if (result == false){
            throw new NotFoundException("You are not following this seller");
        }

    }

    private void loadDataBase() throws IOException {
        File file;
        ObjectMapper objectMapper = new ObjectMapper();
        List<User> usersList;

        file = ResourceUtils.getFile("classpath:users.json");
        usersList = objectMapper.readValue(file, new TypeReference<List<User>>(){});
        users = usersList;
    }
}
