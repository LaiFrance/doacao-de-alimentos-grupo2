package com.g5.TheVelopers.dtos;

import java.time.LocalDate;

import com.g5.TheVelopers.entities.Product;
import com.g5.TheVelopers.entities.PromoPost;

import lombok.Getter;

@Getter
public class PromoPostDto {
    private Integer userId;
    private LocalDate date;
    private ProductDto product;
    private Integer category;
    private Double price;
    private Boolean hasPromo;
    private Double discount;

    public PromoPostDto(PromoPost promoPost, Product product) {
        this.userId = promoPost.getUserId();
        this.date = promoPost.getDate();
        this.product = new ProductDto(product);
        this.category = product.getCategory();
        this.price = product.getPrice();
        this.hasPromo = promoPost.getHasPromo();
        this.discount = promoPost.getDiscount();
    }
}
