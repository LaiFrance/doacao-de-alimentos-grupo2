package com.g5.TheVelopers.dtos;

import com.g5.TheVelopers.entities.Post;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PostRawDto {
    private Integer id;
    private Integer userId;
    private Integer productId;
    private String date;

    public Post toPost() {
        return new Post(this.id, this.userId, this.productId, LocalDate.parse(this.date));
    }
}
